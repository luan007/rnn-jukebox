#include <stdio.h>
#include <stdlib.h>

//导入文件控制函数库
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

//导入i2C的库
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>

//风扇的i2c节点
#define FAN_DEVICE  "/dev/i2c-0"  //根据实际改

//风扇的设备地址 
#define FAN_ADDR  0x0d

//对风扇的寄存器操作
unsigned char fan_reg = 0x08;

int main()
{
  int fd,i,ret =0;
  
  unsigned char wr_buf[5] = {0};
  
  //打开风扇对应的控制器文件
  fd = open(FAN_DEVICE,O_RDWR);
  if(fd< 0)
  {
    fprintf(stderr,"open fan error!\n");
    return -1;
  }

  //设置风扇的I2C地址
  if(ioctl(fd,I2C_SLAVE_FORCE,FAN_ADDR)<0)
  {
    fprintf(stderr,"Set fan error!\n");
    return -1;
  }  
  

  //控制风扇
fan_shu: 
  printf("请选择风扇的速度(0-5):");
  scanf("%d",&ret);
  
  switch(ret)
  {
    case 0 : 
    wr_buf[0] = fan_reg;
    wr_buf[1] = 0x00;
    write(fd, wr_buf, 2);
    break;
    
    case 1 : 
    wr_buf[0] = fan_reg;
    wr_buf[1] = 0x04;
    write(fd, wr_buf, 2);
    break;
    
    case 2 : 
    wr_buf[0] = fan_reg;
    wr_buf[1] = 0x06;
    write(fd, wr_buf, 2);
    break;
    
    case 3 : 
    wr_buf[0] = fan_reg;
    wr_buf[1] = 0x08;
    write(fd, wr_buf, 2);
    break;
  
    case 4 : 
    wr_buf[0] = fan_reg;
    wr_buf[1] = 0x09;
    write(fd, wr_buf, 2);
    break;
    
    case 5 : 
    wr_buf[0] = fan_reg;
    wr_buf[1] = 0x01;
    write(fd, wr_buf, 2);
    break;
    
    default : 
    printf("输入有误，请重新输入\n");
    goto fan_shu;
  }
  
  close(fd);
  return 0;
    

}

