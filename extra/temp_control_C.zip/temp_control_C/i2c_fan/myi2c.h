#ifndef __MYI2C_H
#define __MYI2C_H

#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>

int i2c_write_8(int fd, unsigned char dev_addr, unsigned char reg_addr, unsigned char * data_buf,int len);

int i2c_write_16(int fd, unsigned char dev_addr, unsigned char reg_addr, unsigned char * data_buf,int len);

int i2c_read(int fd, unsigned char dev_addr, unsigned char reg_addr, unsigned char * data_buf,int len);

#endif
