#include "myi2c.h"

//风扇的i2c节点
#define FAN_DEVICE  "/dev/i2c-0"  //根据实际改

//风扇的设备地址 
#define FAN_ADDR  0x0d

//对风扇的寄存器操作
unsigned char fan_reg = 0x08;

int main()
{
  int fd,i,ret =0;
  
  unsigned char wr_buf ;
  
  //打开风扇对应的控制器文件
  fd = open(FAN_DEVICE,O_RDWR);
  if(fd< 0)
  {
    fprintf(stderr,"open fan error!\n");
    return -1;
  }
  
//控制风扇
fan_shu: 
  printf("请选择风扇的速度(0-5):");
  scanf("%d",&ret);
  
  switch(ret)
  {
    case 0 : 
    wr_buf = 0x00;
    break;
    
    case 1 : 
    wr_buf = 0x04;
    break;
    
    case 2 : 
    wr_buf = 0x06;
    break;
    
    case 3 : 
    wr_buf = 0x08;
    break;
  
    case 4 : 
    wr_buf = 0x09;
    break;
    
    case 5 : 
    wr_buf = 0x01;
    break;
    
    default : 
    printf("输入有误，请重新输入\n");
    goto fan_shu;
  }
  
  i2c_write_8(fd,FAN_ADDR,fan_reg,&wr_buf,1);
  close(fd);
  return 0;
    

}

  
    
  
  
  
  
  
