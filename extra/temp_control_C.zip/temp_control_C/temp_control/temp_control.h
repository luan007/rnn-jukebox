#ifndef TEMP_CONTROL_H_
#define TEMP_CONTROL_H_

// 导入I2C库
#include "myi2c.h"
// 导入oled显示屏库
#include "ssd1306_i2c.h"
//导入RGB的库
#include "rgb_temp.h"

// 导入文件控制函数库
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
// 读取IP库
#include <ifaddrs.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
// 读取磁盘库
#include <sys/vfs.h>
#include <unistd.h>

#define RGB_FAN_DEVICE "/dev/i2c-0"  //根据实际改
#define RGB_FAN_ADDR  0x0d

#define CPU_USAGE_PATH "/proc/stat"
#define HARDWARE_PATH "/proc/device-tree/model"
#define TEMP_PATH "/sys/class/thermal/thermal_zone0/temp"
#define MAX_SIZE 32

#endif