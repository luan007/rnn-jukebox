#ifndef RGB_TEMP_H_
#define RGB_TEMP_H_

#include "myi2c.h"

#define Max_LED    3
#define RGB_Effect 0x04 
#define RGB_Speed  0x05
#define RGB_Color  0x06


#define RGB_ADDR 0x0d

void setRGB(int fd_i2c,unsigned char num, unsigned char R, unsigned char G, unsigned char B);

void closeRGB(int fd_i2c);

void setRGBEffect(int fd_i2c,unsigned char effect);
void setRGBSpeed(int fd_i2c,unsigned char speed);
void setRGBColor(int fd_i2c,unsigned char color);



#endif