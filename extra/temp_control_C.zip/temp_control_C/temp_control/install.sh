#!/bin/sh
sudo chmod 777 start.sh install.sh

#rc.local.old存在的话，就说明不是第一次安装了，因此不能在增加了
if [ ! -s /etc/rc.local.c ]; then
	sudo cp /etc/rc.local /etc/rc.local.c
	sudo chmod 777 /etc/rc.local
	sudo echo "sudo /home/sunrise/temp_control/start.sh &" >> /etc/rc.local
	sudo chmod 755 /etc/rc.local
	cd /home/sunrise/temp_control
	gcc -o temp_control *.c
fi




echo 'install ok!'
                          
