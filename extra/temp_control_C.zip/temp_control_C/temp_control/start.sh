#!/bin/sh
sleep 5s
cd /home/sunrise/temp_control/
sudo ./temp_control
