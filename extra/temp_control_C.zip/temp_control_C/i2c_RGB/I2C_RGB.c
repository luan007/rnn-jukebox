#include "myi2c.h"

#define Max_LED    3
#define RGB_Effect 0x04 
#define RGB_Speed  0x05
#define RGB_Color  0x06

int fd_i2c;
unsigned char  data_buf;

void setRGB(unsigned char num, unsigned char R, unsigned char G, unsigned char B);

void closeRGB();

void setRGBEffect(unsigned char effect);
void setRGBSpeed(unsigned char speed);
void setRGBColor(unsigned char color);

#define RGB_DEVICE "/dev/i2c-0"  //根据实际改

#define RGB_ADDR 0x0d

int main(void)
{
    // 定义I2C相关参数
    fd_i2c = open(RGB_DEVICE,O_RDWR);
    if (fd_i2c < 0)
    {
        fprintf(stderr, "fail to init I2C\n");
        return -1;
    }

    closeRGB();
    sleep(1);

    setRGBEffect(1);
    setRGBSpeed(3);
    setRGBColor(4);

    return 0;
}


// 设置RGB灯,num如果大于等于Max_LED（3），则全部灯一起设置
// num=(0~3),R=(0~255),G=(0~255),B=(0~255)
void setRGB(unsigned char num, unsigned char R, unsigned char G, unsigned char B)
{
    if (num >= Max_LED)
    {
    		data_buf = 0xff;
        i2c_write_8(fd_i2c, RGB_ADDR,0x00, &data_buf,1);       
        i2c_write_8(fd_i2c, RGB_ADDR,0x01, &R,1);        
        i2c_write_8(fd_i2c, RGB_ADDR,0x02, &G,1);
        i2c_write_8(fd_i2c, RGB_ADDR,0x03, &B,1);
    
    }
    else if (num >= 0)
    {
        i2c_write_8(fd_i2c, RGB_ADDR,0x00, &num,1);
        i2c_write_8(fd_i2c, RGB_ADDR,0x01, &R,1);
        i2c_write_8(fd_i2c, RGB_ADDR,0x02, &G,1);
        i2c_write_8(fd_i2c, RGB_ADDR,0x03, &B,1);
    }
}



// 关闭RGB
void closeRGB()
{
		data_buf = 0x00;
    i2c_write_8(fd_i2c, RGB_ADDR,0x07, &data_buf,1);
}

// 设置RGB灯效，0流水灯，1呼吸灯,2跑马灯，3彩虹灯，4炫彩灯
void setRGBEffect(unsigned char effect)
{
    if (effect >= 0 && effect <= 4)
    {
        i2c_write_8(fd_i2c,RGB_ADDR, RGB_Effect, &effect,1);
    }  
}

// 设置RGB速度：1低速，2中速（默认），3高速
void setRGBSpeed(unsigned char speed)
{
    if (speed >= 1 && speed <= 3)
    {
    		i2c_write_8(fd_i2c,RGB_ADDR, RGB_Speed, &speed,1);
    }
}
// 设置流水灯/呼吸灯颜色：0红色，1绿色（默认），2蓝色，3黄色，4紫色，5青色，6白色
void setRGBColor(unsigned char color)
{
    if (color >= 0 && color <= 6)
    {
    	i2c_write_8(fd_i2c,RGB_ADDR, RGB_Color, &color,1);
    }
}
